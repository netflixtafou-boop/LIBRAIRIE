-- ==============================================================================
-- 📚 LIBRAIRIE & PAPETERIE SCOLAIRE - SCHÉMA DE BASE DE DONNÉES SUPABASE
-- Script de migration SQL complet avec Row Level Security (RLS) & Données initiales
-- ==============================================================================

-- 1. EXTENSIONS
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. TABLE DES CATÉGORIES
CREATE TABLE IF NOT EXISTS public.categories (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(150) NOT NULL UNIQUE,
    slug VARCHAR(150) NOT NULL UNIQUE,
    description TEXT,
    icon VARCHAR(50) DEFAULT 'book',
    color VARCHAR(30) DEFAULT '#4F46E5',
    display_order INT DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. TABLE DES PRODUITS (LIVRES & FOURNITURES)
CREATE TABLE IF NOT EXISTS public.products (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title VARCHAR(255) NOT NULL,
    category_id UUID REFERENCES public.categories(id) ON DELETE SET NULL,
    type VARCHAR(50) DEFAULT 'livre' CHECK (type IN ('livre', 'fourniture', 'autre')),
    author VARCHAR(255),
    pages_count INT DEFAULT 0,
    description TEXT,
    price NUMERIC(12, 2) NOT NULL DEFAULT 0.00,
    promo_price NUMERIC(12, 2) DEFAULT NULL,
    image_url TEXT,
    stock_quantity INT NOT NULL DEFAULT 1,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    sales_count INT NOT NULL DEFAULT 0,
    isbn_code VARCHAR(50),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 4. TABLE DES COMMANDES (PAIEMENT À LA LIVRAISON)
CREATE TABLE IF NOT EXISTS public.orders (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_number VARCHAR(50) NOT NULL UNIQUE,
    customer_name VARCHAR(255) NOT NULL,
    customer_phone VARCHAR(50) NOT NULL,
    customer_city VARCHAR(150) NOT NULL,
    customer_address TEXT NOT NULL,
    notes TEXT,
    total_amount NUMERIC(12, 2) NOT NULL DEFAULT 0.00,
    payment_method VARCHAR(50) NOT NULL DEFAULT 'Paiement à la livraison',
    status VARCHAR(50) NOT NULL DEFAULT 'en_attente' 
        CHECK (status IN ('en_attente', 'confirmee', 'en_livraison', 'livree', 'annulee')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 5. TABLE DES ARTICLES COMMANDÉS
CREATE TABLE IF NOT EXISTS public.order_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_id UUID NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
    product_id UUID REFERENCES public.products(id) ON DELETE SET NULL,
    product_title VARCHAR(255) NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    unit_price NUMERIC(12, 2) NOT NULL DEFAULT 0.00,
    subtotal NUMERIC(12, 2) NOT NULL DEFAULT 0.00,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 6. TABLE DES VENTES DIRECTES (MAGASIN / CAISSE & COMMANDES)
CREATE TABLE IF NOT EXISTS public.sales (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    product_id UUID REFERENCES public.products(id) ON DELETE SET NULL,
    order_id UUID REFERENCES public.orders(id) ON DELETE SET NULL,
    quantity INT NOT NULL DEFAULT 1,
    unit_price NUMERIC(12, 2) NOT NULL DEFAULT 0.00,
    total_amount NUMERIC(12, 2) NOT NULL DEFAULT 0.00,
    sale_type VARCHAR(50) NOT NULL DEFAULT 'magasin_direct' CHECK (sale_type IN ('magasin_direct', 'commande_en_ligne')),
    payment_method VARCHAR(50) DEFAULT 'Espèces',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 7. TABLE DES PARAMÈTRES DE LA BOUTIQUE
CREATE TABLE IF NOT EXISTS public.settings (
    key VARCHAR(100) PRIMARY KEY,
    value TEXT NOT NULL,
    description TEXT,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 8. INDEX POUR PERFORMANCES
CREATE INDEX IF NOT EXISTS idx_products_category ON public.products(category_id);
CREATE INDEX IF NOT EXISTS idx_products_is_active ON public.products(is_active);
CREATE INDEX IF NOT EXISTS idx_orders_status ON public.orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_created_at ON public.orders(created_at);
CREATE INDEX IF NOT EXISTS idx_sales_created_at ON public.sales(created_at);

-- 9. CONFIGURATION DE ROW LEVEL SECURITY (RLS)
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sales ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.settings ENABLE ROW LEVEL SECURITY;

-- Politiques RLS pour accès public (Storefront) et administrateur (Anon Key)
-- Dans une architecture statique sans authentification Supabase Auth complexe :
-- Le public peut lire les catégories et les produits actifs, et créer des commandes.
-- L'anon key a accès complet pour l'administration.
CREATE POLICY "Categories are readable by everyone" ON public.categories FOR SELECT USING (true);
CREATE POLICY "Categories modifiable by anon" ON public.categories FOR ALL USING (true) WITH CHECK (true);

CREATE POLICY "Products readable by everyone" ON public.products FOR SELECT USING (true);
CREATE POLICY "Products modifiable by anon" ON public.products FOR ALL USING (true) WITH CHECK (true);

CREATE POLICY "Orders insertable by public" ON public.orders FOR INSERT WITH CHECK (true);
CREATE POLICY "Orders readable and modifiable by anon" ON public.orders FOR ALL USING (true) WITH CHECK (true);

CREATE POLICY "Order items insertable by public" ON public.order_items FOR INSERT WITH CHECK (true);
CREATE POLICY "Order items readable and modifiable by anon" ON public.order_items FOR ALL USING (true) WITH CHECK (true);

CREATE POLICY "Sales readable and insertable by anon" ON public.sales FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Settings readable and modifiable by anon" ON public.settings FOR ALL USING (true) WITH CHECK (true);

-- 10. INSERTION DES PARAMÈTRES PAR DÉFAUT
INSERT INTO public.settings (key, value, description)
VALUES 
    ('store_name', 'Librairie & Papeterie Scolaire Moderne', 'Nom de la boutique'),
    ('admin_password', 'admin123', 'Mot de passe d''accès à l''administration'),
    ('currency', 'FCFA', 'Symbole monétaire (ex: FCFA, €, DA, DH)'),
    ('contact_phone', '+221 77 123 45 67', 'Numéro de contact officiel'),
    ('delivery_info', 'Livraison rapide à domicile sous 24h à 48h. Paiement en espèces à la réception.', 'Notice de livraison')
ON CONFLICT (key) DO NOTHING;

-- 11. INSERTION DES CATÉGORIES INITIALES
INSERT INTO public.categories (id, name, slug, description, icon, color, display_order)
VALUES 
    ('a1111111-1111-1111-1111-111111111111', 'Livres & Romans', 'livres-romans', 'Littérature, romans africains et classiques internationaux', 'book-open', '#4F46E5', 1),
    ('b2222222-2222-2222-2222-222222222222', 'Fournitures Scolaires', 'fournitures-scolaires', 'Cahiers, stylos, règles, trousses et matériel scolaire complet', 'pen-tool', '#D97706', 2),
    ('c3333333-3333-3333-3333-333333333333', 'Manuels & Parascolaire', 'manuels-parascolaire', 'Livres de cours, annales, dictionnaires et guides de révision', 'graduation-cap', '#10B981', 3),
    ('d4444444-4444-4444-4444-444444444444', 'Jeunesse & Bandes Dessinées', 'jeunesse-bd', 'Contes illustrés, bandes dessinées et livres d''éveil pour enfants', 'smile', '#EC4899', 4),
    ('e5555555-5555-5555-5555-555555555555', 'Papeterie & Bureau', 'papeterie-bureau', 'Classeurs, ramettes de papier, calculatrices et accessoires de bureau', 'briefcase', '#6366F1', 5)
ON CONFLICT (name) DO NOTHING;

-- 12. INSERTION DE PRODUITS INITIAUX AVEC NOMBRE DE PAGES
INSERT INTO public.products (title, category_id, type, author, pages_count, description, price, promo_price, image_url, stock_quantity, is_active, sales_count)
VALUES
    ('Une Si Longue Lettre', 'a1111111-1111-1111-1111-111111111111', 'livre', 'Mariama Bâ', 165, 'Chef-d''œuvre de la littérature africaine. À travers la lettre que Ramatoulaye adresse à son amie Aïssatou, une réflexion bouleversante sur la condition féminine et les traditions.', 4500.00, 4000.00, 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&w=600&q=80', 25, true, 18),
    ('Le Petit Prince', 'a1111111-1111-1111-1111-111111111111', 'livre', 'Antoine de Saint-Exupéry', 120, 'Un conte poétique et philosophique universel illustré de dessins de l''auteur. Une lecture incontournable pour tous les âges.', 3500.00, NULL, 'https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=600&q=80', 40, true, 34),
    ('L''Étranger', 'a1111111-1111-1111-1111-111111111111', 'livre', 'Albert Camus', 184, 'Roman culte décrivant avec une lucidité désarmante la vie de Meursault sous le soleil brûlant d''Alger.', 4200.00, NULL, 'https://images.unsplash.com/photo-1495446815901-a7297e633e8d?auto=format&fit=crop&w=600&q=80', 15, true, 12),
    ('Pack Rentrée : 5 Cahiers 200 Pages + Trousse', 'b2222222-2222-2222-2222-222222222222', 'fourniture', 'Clairefontaine / Bic', 200, 'Lot économique pour la rentrée scolaire comprenant 5 grands cahiers 200 pages grand carreaux et une trousse garnie de stylos 4 couleurs.', 6500.00, 5800.00, 'https://images.unsplash.com/photo-1585776245991-cf89dd7fc73a?auto=format&fit=crop&w=600&q=80', 50, true, 42),
    ('Dictionnaire Larousse Illustré 2026', 'c3333333-3333-3333-3333-333333333333', 'livre', 'Éditions Larousse', 1280, 'Le dictionnaire de référence avec plus de 64 000 mots, 28 000 noms propres et des planches illustrées en couleurs.', 16000.00, 14500.00, 'https://images.unsplash.com/photo-1589829085413-56de8ae18c73?auto=format&fit=crop&w=600&q=80', 10, true, 7),
    ('Calculatrice Scientifique FX-92 Spéciale Collège', 'b2222222-2222-2222-2222-222222222222', 'fourniture', 'Casio', 0, 'La calculatrice indispensable pour les programmes du collège et du lycée. Menus entièrement en français.', 18500.00, NULL, 'https://images.unsplash.com/photo-1611125832047-1d7ad1e8e48f?auto=format&fit=crop&w=600&q=80', 14, true, 9),
    ('Les Aventures de Tintin : Le Lotus Bleu', 'd4444444-4444-4444-4444-444444444444', 'livre', 'Hergé', 64, 'Album culte en couleurs. Une formidable aventure en Extrême-Orient au suspense haletant et aux décors somptueux.', 7000.00, NULL, 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=600&q=80', 8, true, 15),
    ('Ramette Papier A4 80g Extra Blanc (500 feuilles)', 'e5555555-5555-5555-5555-555555555555', 'fourniture', 'Navigator', 500, 'Papier de bureau de très haute qualité pour photocopies et impressions laser/jet d''encre sans bourrage.', 4000.00, NULL, 'https://images.unsplash.com/photo-1586075010923-2dd4570fb338?auto=format&fit=crop&w=600&q=80', 60, true, 28);
